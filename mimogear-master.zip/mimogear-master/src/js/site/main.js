(function() {

  var menuTrigger = Trigger.init({
    trigger: '.menu-trigger',
    bodyClass: 'menu-activated'
  });

  Lantern.init();

  Sail.init();

})();
