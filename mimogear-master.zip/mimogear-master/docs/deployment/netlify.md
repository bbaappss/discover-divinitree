# netlify

netlify is pretty easy to setup. If you're gonna choose the netlify route, create an account, add a new project, choose a github repository, then configure continuous deployment when you get to the settings page:

![netlify continuous deployment](http://image.prntscr.com/image/c368e9cac8f944cdb17aec8014145327.png)

If you need to go back to edit these settings later, you can find them on your individual project's page within the "Link to Git" section:

![netlify configuration](http://image.prntscr.com/image/12df3ccb8e734179a21addd784fa4721.png)
