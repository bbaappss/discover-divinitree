# Vendor

The vendor folder contains any vendor css components that you wish to add to the site. Just add in a new vendor css file here and it will be automatically compiled into the main stylesheet.

## Normalize

Normalize is included to make sure that all styles are consistent within each browser by default.
